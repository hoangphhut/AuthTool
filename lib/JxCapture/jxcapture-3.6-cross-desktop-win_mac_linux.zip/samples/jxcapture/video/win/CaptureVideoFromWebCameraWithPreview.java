package jxcapture.video.win;

import com.teamdev.jxcapture.Codec;
import com.teamdev.jxcapture.EncodingParameters;
import com.teamdev.jxcapture.ImageCapture;
import com.teamdev.jxcapture.VideoCapture;
import com.teamdev.jxcapture.video.VideoFormat;
import com.teamdev.jxcapture.video.VideoSource;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

/**
 * This example demonstrates the video capture from web camera.
 * <pre>
 * Platforms:           Windows
 * Image source:        WebCamera
 * Output video format: WMV
 * Output file:         WebCamera.wmv
 *
 * @author Serge Piletsky
 */
public class CaptureVideoFromWebCameraWithPreview {

    public static void main(String[] args) throws Exception {
        VideoCapture videoCapture = VideoCapture.create(VideoFormat.WMV);

        List<VideoSource> availableVideoSources = VideoSource.getAvailable();
        System.out.println("availableVideoSources = " + availableVideoSources);

        if (availableVideoSources.isEmpty()) {
            throw new IllegalStateException("No external video sources available");
        }
        VideoSource webCamera = availableVideoSources.get(0);
        System.out.println("webCamera = " + webCamera);

        videoCapture.setVideoSource(webCamera);

        List<Codec> videoCodecs = videoCapture.getVideoCodecs();
        System.out.println("videoCodecs = " + videoCodecs);
        if (videoCodecs.isEmpty()) {
            throw new IllegalStateException("No video codecs available");
        }

        Codec videoCodec = videoCodecs.get(2);
        System.out.println("videoCodec = " + videoCodec);

        EncodingParameters encodingParameters = new EncodingParameters(new File("WebCamera.wmv"));
        encodingParameters.setBitrate(500000);
        encodingParameters.setFramerate(10);
        encodingParameters.setKeyFrameInterval(1);
        encodingParameters.setCodec(videoCodec);

        final ImageCapture imageCapture = ImageCapture.create(webCamera);
        JFrame preview = new JFrame("Preview Window");
        preview.setSize(640, 480);
        preview.setLocationRelativeTo(null);
        final JLabel imageLabel = new JLabel();
        Container contentPane = preview.getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(imageLabel, BorderLayout.CENTER);
        preview.setVisible(true);

        // update image on preview window every 200 milliseconds
        Timer timer = new Timer(200, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                imageCapture.takeSnapshot();
                BufferedImage image = imageCapture.getImage();
                imageLabel.setIcon(new ImageIcon(image));
                imageCapture.release();
            }
        });

        timer.start();
        videoCapture.setEncodingParameters(encodingParameters);
        videoCapture.start();

        System.out.println("Recording started. Press 'Enter' to terminate.");
        System.in.read();
        timer.stop();
        preview.dispose();
        videoCapture.stop();
    }
}
